package com.example.anime_hub

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
