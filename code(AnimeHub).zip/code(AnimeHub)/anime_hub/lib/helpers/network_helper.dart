import 'package:anime_hub/helpers/network_error_handler.dart';
import 'package:anime_hub/helpers/toast_messages.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class NetworkHelper {
  static Future<http.Response?> getData({
    required String url,
    Map<String, dynamic>? query,
    required BuildContext context,
  }) async {
    try {
      Uri uri = Uri.parse(url).replace(queryParameters: query);
      final headers = {'Content-Type': 'application/json'};
      final response = await http.get(uri, headers: headers);
      return NetworkErrorHandler(response: response, context: context);
    } catch (e) {
      _handleUnexpectedError(context, e);
      return null;
    }
  }

  static void _handleUnexpectedError(BuildContext context, dynamic error) {
    showToastMessage(
      message: "Please check your Internet Connection, & Try Aaian.",
      context: context,
    );
  }
}
