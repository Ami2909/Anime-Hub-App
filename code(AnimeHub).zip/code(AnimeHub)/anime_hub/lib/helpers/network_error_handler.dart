import 'dart:convert';

import 'package:anime_hub/helpers/toast_messages.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

Future<http.Response?> NetworkErrorHandler({
  required http.Response? response,
  required BuildContext context,
}) async {
  try {
    if (response != null) {
      final statusCode = response.statusCode;
      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return response;
      } else if (statusCode >= 400) {
        showToastMessage(
          message: data['message'] ?? "Sorry Some Error occured.",
          context: context,
        );
        return null;
      } else {
        return null;
      }
    } else {
      return null;
    }
  } catch (e) {
    showToastMessage(message: "Sorry Some Error occured.", context: context);
    return null;
  }
}
