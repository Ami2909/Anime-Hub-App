class AnimeModel {
    AnimeModel({
        required this.pagination,
        required this.data,
    });

    final Pagination? pagination;
    final List<Datum> data;

    AnimeModel copyWith({
        Pagination? pagination,
        List<Datum>? data,
    }) {
        return AnimeModel(
            pagination: pagination ?? this.pagination,
            data: data ?? this.data,
        );
    }

    factory AnimeModel.fromJson(Map<String, dynamic> json){ 
        return AnimeModel(
            pagination: json["pagination"] == null ? null : Pagination.fromJson(json["pagination"]),
            data: json["data"] == null ? [] : List<Datum>.from(json["data"]!.map((x) => Datum.fromJson(x))),
        );
    }

    Map<String, dynamic> toJson() => {
        "pagination": pagination?.toJson(),
        "data": data.map((x) => x?.toJson()).toList(),
    };

    @override
    String toString(){
        return "$pagination, $data, ";
    }
}

class Datum {
    Datum({
        required this.malId,
        required this.url,
        required this.images,
        required this.trailer,
        required this.approved,
        required this.titles,
        required this.title,
        required this.titleEnglish,
        required this.titleJapanese,
        required this.titleSynonyms,
        required this.type,
        required this.source,
        required this.episodes,
        required this.status,
        required this.airing,
        required this.aired,
        required this.duration,
        required this.rating,
        required this.score,
        required this.scoredBy,
        required this.rank,
        required this.popularity,
        required this.members,
        required this.favorites,
        required this.synopsis,
        required this.background,
        required this.season,
        required this.year,
        required this.broadcast,
        required this.producers,
        required this.licensors,
        required this.studios,
        required this.genres,
        required this.explicitGenres,
        required this.themes,
        required this.demographics,
    });

    final int? malId;
    final String? url;
    final Map<String, Image> images;
    final Trailer? trailer;
    final bool? approved;
    final List<Title> titles;
    final String? title;
    final String? titleEnglish;
    final String? titleJapanese;
    final List<String> titleSynonyms;
    final String? type;
    final String? source;
    final int? episodes;
    final String? status;
    final bool? airing;
    final Aired? aired;
    final String? duration;
    final String? rating;
    final double? score;
    final int? scoredBy;
    final int? rank;
    final int? popularity;
    final int? members;
    final int? favorites;
    final String? synopsis;
    final String? background;
    final dynamic season;
    final dynamic year;
    final Broadcast? broadcast;
    final List<Demographic> producers;
    final List<Demographic> licensors;
    final List<Demographic> studios;
    final List<Demographic> genres;
    final List<dynamic> explicitGenres;
    final List<Demographic> themes;
    final List<Demographic> demographics;

    Datum copyWith({
        int? malId,
        String? url,
        Map<String, Image>? images,
        Trailer? trailer,
        bool? approved,
        List<Title>? titles,
        String? title,
        String? titleEnglish,
        String? titleJapanese,
        List<String>? titleSynonyms,
        String? type,
        String? source,
        int? episodes,
        String? status,
        bool? airing,
        Aired? aired,
        String? duration,
        String? rating,
        double? score,
        int? scoredBy,
        int? rank,
        int? popularity,
        int? members,
        int? favorites,
        String? synopsis,
        String? background,
        dynamic? season,
        dynamic? year,
        Broadcast? broadcast,
        List<Demographic>? producers,
        List<Demographic>? licensors,
        List<Demographic>? studios,
        List<Demographic>? genres,
        List<dynamic>? explicitGenres,
        List<Demographic>? themes,
        List<Demographic>? demographics,
    }) {
        return Datum(
            malId: malId ?? this.malId,
            url: url ?? this.url,
            images: images ?? this.images,
            trailer: trailer ?? this.trailer,
            approved: approved ?? this.approved,
            titles: titles ?? this.titles,
            title: title ?? this.title,
            titleEnglish: titleEnglish ?? this.titleEnglish,
            titleJapanese: titleJapanese ?? this.titleJapanese,
            titleSynonyms: titleSynonyms ?? this.titleSynonyms,
            type: type ?? this.type,
            source: source ?? this.source,
            episodes: episodes ?? this.episodes,
            status: status ?? this.status,
            airing: airing ?? this.airing,
            aired: aired ?? this.aired,
            duration: duration ?? this.duration,
            rating: rating ?? this.rating,
            score: score ?? this.score,
            scoredBy: scoredBy ?? this.scoredBy,
            rank: rank ?? this.rank,
            popularity: popularity ?? this.popularity,
            members: members ?? this.members,
            favorites: favorites ?? this.favorites,
            synopsis: synopsis ?? this.synopsis,
            background: background ?? this.background,
            season: season ?? this.season,
            year: year ?? this.year,
            broadcast: broadcast ?? this.broadcast,
            producers: producers ?? this.producers,
            licensors: licensors ?? this.licensors,
            studios: studios ?? this.studios,
            genres: genres ?? this.genres,
            explicitGenres: explicitGenres ?? this.explicitGenres,
            themes: themes ?? this.themes,
            demographics: demographics ?? this.demographics,
        );
    }

    factory Datum.fromJson(Map<String, dynamic> json){ 
        return Datum(
            malId: json["mal_id"],
            url: json["url"],
            images: Map.from(json["images"]).map((k, v) => MapEntry<String, Image>(k, Image.fromJson(v))),
            trailer: json["trailer"] == null ? null : Trailer.fromJson(json["trailer"]),
            approved: json["approved"],
            titles: json["titles"] == null ? [] : List<Title>.from(json["titles"]!.map((x) => Title.fromJson(x))),
            title: json["title"],
            titleEnglish: json["title_english"],
            titleJapanese: json["title_japanese"],
            titleSynonyms: json["title_synonyms"] == null ? [] : List<String>.from(json["title_synonyms"]!.map((x) => x)),
            type: json["type"],
            source: json["source"],
            episodes: json["episodes"],
            status: json["status"],
            airing: json["airing"],
            aired: json["aired"] == null ? null : Aired.fromJson(json["aired"]),
            duration: json["duration"],
            rating: json["rating"],
            score: json["score"],
            scoredBy: json["scored_by"],
            rank: json["rank"],
            popularity: json["popularity"],
            members: json["members"],
            favorites: json["favorites"],
            synopsis: json["synopsis"],
            background: json["background"],
            season: json["season"],
            year: json["year"],
            broadcast: json["broadcast"] == null ? null : Broadcast.fromJson(json["broadcast"]),
            producers: json["producers"] == null ? [] : List<Demographic>.from(json["producers"]!.map((x) => Demographic.fromJson(x))),
            licensors: json["licensors"] == null ? [] : List<Demographic>.from(json["licensors"]!.map((x) => Demographic.fromJson(x))),
            studios: json["studios"] == null ? [] : List<Demographic>.from(json["studios"]!.map((x) => Demographic.fromJson(x))),
            genres: json["genres"] == null ? [] : List<Demographic>.from(json["genres"]!.map((x) => Demographic.fromJson(x))),
            explicitGenres: json["explicit_genres"] == null ? [] : List<dynamic>.from(json["explicit_genres"]!.map((x) => x)),
            themes: json["themes"] == null ? [] : List<Demographic>.from(json["themes"]!.map((x) => Demographic.fromJson(x))),
            demographics: json["demographics"] == null ? [] : List<Demographic>.from(json["demographics"]!.map((x) => Demographic.fromJson(x))),
        );
    }

    Map<String, dynamic> toJson() => {
        "mal_id": malId,
        "url": url,
        "images": Map.from(images).map((k, v) => MapEntry<String, dynamic>(k, v?.toJson())),
        "trailer": trailer?.toJson(),
        "approved": approved,
        "titles": titles.map((x) => x?.toJson()).toList(),
        "title": title,
        "title_english": titleEnglish,
        "title_japanese": titleJapanese,
        "title_synonyms": titleSynonyms.map((x) => x).toList(),
        "type": type,
        "source": source,
        "episodes": episodes,
        "status": status,
        "airing": airing,
        "aired": aired?.toJson(),
        "duration": duration,
        "rating": rating,
        "score": score,
        "scored_by": scoredBy,
        "rank": rank,
        "popularity": popularity,
        "members": members,
        "favorites": favorites,
        "synopsis": synopsis,
        "background": background,
        "season": season,
        "year": year,
        "broadcast": broadcast?.toJson(),
        "producers": producers.map((x) => x?.toJson()).toList(),
        "licensors": licensors.map((x) => x?.toJson()).toList(),
        "studios": studios.map((x) => x?.toJson()).toList(),
        "genres": genres.map((x) => x?.toJson()).toList(),
        "explicit_genres": explicitGenres.map((x) => x).toList(),
        "themes": themes.map((x) => x?.toJson()).toList(),
        "demographics": demographics.map((x) => x?.toJson()).toList(),
    };

    @override
    String toString(){
        return "$malId, $url, $images, $trailer, $approved, $titles, $title, $titleEnglish, $titleJapanese, $titleSynonyms, $type, $source, $episodes, $status, $airing, $aired, $duration, $rating, $score, $scoredBy, $rank, $popularity, $members, $favorites, $synopsis, $background, $season, $year, $broadcast, $producers, $licensors, $studios, $genres, $explicitGenres, $themes, $demographics, ";
    }
}

class Aired {
    Aired({
        required this.from,
        required this.to,
        required this.prop,
        required this.string,
    });

    final DateTime? from;
    final dynamic to;
    final Prop? prop;
    final String? string;

    Aired copyWith({
        DateTime? from,
        dynamic? to,
        Prop? prop,
        String? string,
    }) {
        return Aired(
            from: from ?? this.from,
            to: to ?? this.to,
            prop: prop ?? this.prop,
            string: string ?? this.string,
        );
    }

    factory Aired.fromJson(Map<String, dynamic> json){ 
        return Aired(
            from: DateTime.tryParse(json["from"] ?? ""),
            to: json["to"],
            prop: json["prop"] == null ? null : Prop.fromJson(json["prop"]),
            string: json["string"],
        );
    }

    Map<String, dynamic> toJson() => {
        "from": from?.toIso8601String(),
        "to": to,
        "prop": prop?.toJson(),
        "string": string,
    };

    @override
    String toString(){
        return "$from, $to, $prop, $string, ";
    }
}

class Prop {
    Prop({
        required this.from,
        required this.to,
    });

    final From? from;
    final From? to;

    Prop copyWith({
        From? from,
        From? to,
    }) {
        return Prop(
            from: from ?? this.from,
            to: to ?? this.to,
        );
    }

    factory Prop.fromJson(Map<String, dynamic> json){ 
        return Prop(
            from: json["from"] == null ? null : From.fromJson(json["from"]),
            to: json["to"] == null ? null : From.fromJson(json["to"]),
        );
    }

    Map<String, dynamic> toJson() => {
        "from": from?.toJson(),
        "to": to?.toJson(),
    };

    @override
    String toString(){
        return "$from, $to, ";
    }
}

class From {
    From({
        required this.day,
        required this.month,
        required this.year,
    });

    final int? day;
    final int? month;
    final int? year;

    From copyWith({
        int? day,
        int? month,
        int? year,
    }) {
        return From(
            day: day ?? this.day,
            month: month ?? this.month,
            year: year ?? this.year,
        );
    }

    factory From.fromJson(Map<String, dynamic> json){ 
        return From(
            day: json["day"],
            month: json["month"],
            year: json["year"],
        );
    }

    Map<String, dynamic> toJson() => {
        "day": day,
        "month": month,
        "year": year,
    };

    @override
    String toString(){
        return "$day, $month, $year, ";
    }
}

class Broadcast {
    Broadcast({
        required this.day,
        required this.time,
        required this.timezone,
        required this.string,
    });

    final dynamic day;
    final dynamic time;
    final dynamic timezone;
    final dynamic string;

    Broadcast copyWith({
        dynamic? day,
        dynamic? time,
        dynamic? timezone,
        dynamic? string,
    }) {
        return Broadcast(
            day: day ?? this.day,
            time: time ?? this.time,
            timezone: timezone ?? this.timezone,
            string: string ?? this.string,
        );
    }

    factory Broadcast.fromJson(Map<String, dynamic> json){ 
        return Broadcast(
            day: json["day"],
            time: json["time"],
            timezone: json["timezone"],
            string: json["string"],
        );
    }

    Map<String, dynamic> toJson() => {
        "day": day,
        "time": time,
        "timezone": timezone,
        "string": string,
    };

    @override
    String toString(){
        return "$day, $time, $timezone, $string, ";
    }
}

class Demographic {
    Demographic({
        required this.malId,
        required this.type,
        required this.name,
        required this.url,
    });

    final int? malId;
    final String? type;
    final String? name;
    final String? url;

    Demographic copyWith({
        int? malId,
        String? type,
        String? name,
        String? url,
    }) {
        return Demographic(
            malId: malId ?? this.malId,
            type: type ?? this.type,
            name: name ?? this.name,
            url: url ?? this.url,
        );
    }

    factory Demographic.fromJson(Map<String, dynamic> json){ 
        return Demographic(
            malId: json["mal_id"],
            type: json["type"],
            name: json["name"],
            url: json["url"],
        );
    }

    Map<String, dynamic> toJson() => {
        "mal_id": malId,
        "type": type,
        "name": name,
        "url": url,
    };

    @override
    String toString(){
        return "$malId, $type, $name, $url, ";
    }
}

class Image {
    Image({
        required this.imageUrl,
        required this.smallImageUrl,
        required this.largeImageUrl,
    });

    final String? imageUrl;
    final String? smallImageUrl;
    final String? largeImageUrl;

    Image copyWith({
        String? imageUrl,
        String? smallImageUrl,
        String? largeImageUrl,
    }) {
        return Image(
            imageUrl: imageUrl ?? this.imageUrl,
            smallImageUrl: smallImageUrl ?? this.smallImageUrl,
            largeImageUrl: largeImageUrl ?? this.largeImageUrl,
        );
    }

    factory Image.fromJson(Map<String, dynamic> json){ 
        return Image(
            imageUrl: json["image_url"],
            smallImageUrl: json["small_image_url"],
            largeImageUrl: json["large_image_url"],
        );
    }

    Map<String, dynamic> toJson() => {
        "image_url": imageUrl,
        "small_image_url": smallImageUrl,
        "large_image_url": largeImageUrl,
    };

    @override
    String toString(){
        return "$imageUrl, $smallImageUrl, $largeImageUrl, ";
    }
}

class Title {
    Title({
        required this.type,
        required this.title,
    });

    final String? type;
    final String? title;

    Title copyWith({
        String? type,
        String? title,
    }) {
        return Title(
            type: type ?? this.type,
            title: title ?? this.title,
        );
    }

    factory Title.fromJson(Map<String, dynamic> json){ 
        return Title(
            type: json["type"],
            title: json["title"],
        );
    }

    Map<String, dynamic> toJson() => {
        "type": type,
        "title": title,
    };

    @override
    String toString(){
        return "$type, $title, ";
    }
}

class Trailer {
    Trailer({
        required this.youtubeId,
        required this.url,
        required this.embedUrl,
        required this.images,
    });

    final dynamic youtubeId;
    final dynamic url;
    final String? embedUrl;
    final Images? images;

    Trailer copyWith({
        dynamic? youtubeId,
        dynamic? url,
        String? embedUrl,
        Images? images,
    }) {
        return Trailer(
            youtubeId: youtubeId ?? this.youtubeId,
            url: url ?? this.url,
            embedUrl: embedUrl ?? this.embedUrl,
            images: images ?? this.images,
        );
    }

    factory Trailer.fromJson(Map<String, dynamic> json){ 
        return Trailer(
            youtubeId: json["youtube_id"],
            url: json["url"],
            embedUrl: json["embed_url"],
            images: json["images"] == null ? null : Images.fromJson(json["images"]),
        );
    }

    Map<String, dynamic> toJson() => {
        "youtube_id": youtubeId,
        "url": url,
        "embed_url": embedUrl,
        "images": images?.toJson(),
    };

    @override
    String toString(){
        return "$youtubeId, $url, $embedUrl, $images, ";
    }
}

class Images {
    Images({
        required this.imageUrl,
        required this.smallImageUrl,
        required this.mediumImageUrl,
        required this.largeImageUrl,
        required this.maximumImageUrl,
    });

    final dynamic imageUrl;
    final dynamic smallImageUrl;
    final dynamic mediumImageUrl;
    final dynamic largeImageUrl;
    final dynamic maximumImageUrl;

    Images copyWith({
        dynamic? imageUrl,
        dynamic? smallImageUrl,
        dynamic? mediumImageUrl,
        dynamic? largeImageUrl,
        dynamic? maximumImageUrl,
    }) {
        return Images(
            imageUrl: imageUrl ?? this.imageUrl,
            smallImageUrl: smallImageUrl ?? this.smallImageUrl,
            mediumImageUrl: mediumImageUrl ?? this.mediumImageUrl,
            largeImageUrl: largeImageUrl ?? this.largeImageUrl,
            maximumImageUrl: maximumImageUrl ?? this.maximumImageUrl,
        );
    }

    factory Images.fromJson(Map<String, dynamic> json){ 
        return Images(
            imageUrl: json["image_url"],
            smallImageUrl: json["small_image_url"],
            mediumImageUrl: json["medium_image_url"],
            largeImageUrl: json["large_image_url"],
            maximumImageUrl: json["maximum_image_url"],
        );
    }

    Map<String, dynamic> toJson() => {
        "image_url": imageUrl,
        "small_image_url": smallImageUrl,
        "medium_image_url": mediumImageUrl,
        "large_image_url": largeImageUrl,
        "maximum_image_url": maximumImageUrl,
    };

    @override
    String toString(){
        return "$imageUrl, $smallImageUrl, $mediumImageUrl, $largeImageUrl, $maximumImageUrl, ";
    }
}

class Pagination {
    Pagination({
        required this.lastVisiblePage,
        required this.hasNextPage,
        required this.currentPage,
        required this.items,
    });

    final int? lastVisiblePage;
    final bool? hasNextPage;
    final int? currentPage;
    final Items? items;

    Pagination copyWith({
        int? lastVisiblePage,
        bool? hasNextPage,
        int? currentPage,
        Items? items,
    }) {
        return Pagination(
            lastVisiblePage: lastVisiblePage ?? this.lastVisiblePage,
            hasNextPage: hasNextPage ?? this.hasNextPage,
            currentPage: currentPage ?? this.currentPage,
            items: items ?? this.items,
        );
    }

    factory Pagination.fromJson(Map<String, dynamic> json){ 
        return Pagination(
            lastVisiblePage: json["last_visible_page"],
            hasNextPage: json["has_next_page"],
            currentPage: json["current_page"],
            items: json["items"] == null ? null : Items.fromJson(json["items"]),
        );
    }

    Map<String, dynamic> toJson() => {
        "last_visible_page": lastVisiblePage,
        "has_next_page": hasNextPage,
        "current_page": currentPage,
        "items": items?.toJson(),
    };

    @override
    String toString(){
        return "$lastVisiblePage, $hasNextPage, $currentPage, $items, ";
    }
}

class Items {
    Items({
        required this.count,
        required this.total,
        required this.perPage,
    });

    final int? count;
    final int? total;
    final int? perPage;

    Items copyWith({
        int? count,
        int? total,
        int? perPage,
    }) {
        return Items(
            count: count ?? this.count,
            total: total ?? this.total,
            perPage: perPage ?? this.perPage,
        );
    }

    factory Items.fromJson(Map<String, dynamic> json){ 
        return Items(
            count: json["count"],
            total: json["total"],
            perPage: json["per_page"],
        );
    }

    Map<String, dynamic> toJson() => {
        "count": count,
        "total": total,
        "per_page": perPage,
    };

    @override
    String toString(){
        return "$count, $total, $perPage, ";
    }
}
