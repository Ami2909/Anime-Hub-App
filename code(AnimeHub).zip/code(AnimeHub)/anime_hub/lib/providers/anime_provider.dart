import 'dart:convert';

import 'package:anime_hub/helpers/network_helper.dart';
import 'package:anime_hub/models/anime_model.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AnimeProvider extends ChangeNotifier {
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  AnimeModel _animeData = AnimeModel(pagination: null, data: []);
  AnimeModel get animeData => _animeData;

  Future<void> getAnimeData({required BuildContext context}) async {
    _isLoading = true;
    notifyListeners();
    try {
      http.Response? response = await NetworkHelper.getData(
        url: "https://api.jikan.moe/v4/top/anime?type=movie",
        context: context,
      );
      if (response != null) {
        _animeData = AnimeModel.fromJson(jsonDecode(response.body));
        _isLoading = false;
      }
    } catch (e) {
      _animeData = AnimeModel(pagination: null, data: []);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
