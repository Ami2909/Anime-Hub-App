import 'package:anime_hub/constants/app_theme.dart';
import 'package:anime_hub/providers/anime_provider.dart';
import 'package:anime_hub/screens/main_page.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AnimeHubApp extends StatelessWidget {
  const AnimeHubApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [ChangeNotifierProvider(create: (_) => AnimeProvider())],
      child: MaterialApp(
        title: 'Slack Chat',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.dark,
        home: MainPage(),
      ),
    );
  }
}
