import 'package:anime_hub/constants/app_colors.dart';
import 'package:anime_hub/models/anime_model.dart';
import 'package:anime_hub/screens/detail_page.dart';
import 'package:flutter/material.dart';

class AnimeThumbnailWidget extends StatelessWidget {
  const AnimeThumbnailWidget({
    super.key,
    required this.data,
    required this.isLoading,
  });
  final Datum data;
  final bool isLoading;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (!isLoading) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (builder) => DetailPage(data: data)),
          );
        }
      },
      child: Column(
        children: [
          Stack(
            children: [
              Container(
                width: 135,
                height: 190,
                decoration: BoxDecoration(
                  color: Colors.grey,
                  image: DecorationImage(
                    image: NetworkImage(data.images["webp"]?.imageUrl ?? ""),
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                margin: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.appRedColor,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.star, color: Colors.white, size: 16),
                    SizedBox(width: 4),
                    Text(
                      data.score.toString(),
                      style: Theme.of(
                        context,
                      ).textTheme.bodyMedium?.copyWith(color: Colors.white),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 5),
          SizedBox(
            width: 135,
            child: Text(
              data.titleEnglish ?? "",
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ),
        ],
      ),
    );
  }
}
