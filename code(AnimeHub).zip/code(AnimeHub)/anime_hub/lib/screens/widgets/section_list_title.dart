import 'package:anime_hub/constants/app_colors.dart';
import 'package:flutter/material.dart';

class SectionListTitle extends StatelessWidget {
  SectionListTitle({super.key, required this.title});
  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(title, style: Theme.of(context).textTheme.headlineMedium),
          Text(
            "View All",
            style: Theme.of(
              context,
            ).textTheme.bodyLarge?.copyWith(color: AppColors.appRedColor),
          ),
        ],
      ),
    );
  }
}
