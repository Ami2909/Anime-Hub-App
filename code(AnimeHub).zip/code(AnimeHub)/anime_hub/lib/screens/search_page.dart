import 'package:anime_hub/constants/shimmer_container.dart';
import 'package:anime_hub/models/anime_model.dart';
import 'package:anime_hub/providers/anime_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final TextEditingController _searchController = TextEditingController();

  List<Datum> _allAnime = [];
  List<Datum> _filteredAnime = [];

  bool _isInitialized = false;

  void _onSearch(String query) {
    setState(() {
      if (query.isEmpty) {
        _filteredAnime = _allAnime;
      } else {
        _filteredAnime = _allAnime
            .where(
              (anime) =>
                  anime.titleEnglish?.toLowerCase().contains(
                    query.toLowerCase(),
                  ) ??
                  false,
            )
            .toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AnimeProvider>(
      builder: (context, animeProvider, child) {
        // Initialize only once
        if (!_isInitialized && animeProvider.animeData.data.isNotEmpty) {
          _allAnime = animeProvider.animeData.data;
          _filteredAnime = _allAnime;
          _isInitialized = true;
        }

        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 12.0, bottom: 20),
                  child: TextField(
                    controller: _searchController,
                    onChanged: _onSearch,
                    decoration: InputDecoration(
                      hintText: 'Search Anime',
                      prefixIcon: const Icon(Icons.search),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: GridView.builder(
                    itemCount: animeProvider.isLoading
                        ? 10
                        : _filteredAnime.length,
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 16,
                          mainAxisSpacing: 24,
                          childAspectRatio: 1,
                        ),
                    itemBuilder: (context, index) {
                      final anime = _filteredAnime[index];

                      return animeProvider.isLoading
                          ? GlobalShimmer(height: 100, width: 100)
                          : Column(
                              children: [
                                Expanded(
                                  child: Card(
                                    margin: EdgeInsets.all(0),
                                    elevation: 4,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Center(
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(12),
                                          image: DecorationImage(
                                            image: NetworkImage(
                                              anime.images["webp"]?.imageUrl ??
                                                  "",
                                            ),
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  anime.titleEnglish ?? "",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.bodyLarge,
                                ),
                              ],
                            );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
