import 'package:anime_hub/constants/shimmer_container.dart';
import 'package:anime_hub/providers/anime_provider.dart';
import 'package:anime_hub/screens/widgets/anime_thumbnail_widget.dart';
import 'package:anime_hub/screens/widgets/section_list_title.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Consumer<AnimeProvider>(
      builder: (context, animeProvider, child) {
        return !animeProvider.isLoading && animeProvider.animeData.data.isEmpty
            ? Text(
                "Data not Available",
                style: Theme.of(context).textTheme.displayLarge,
              )
            : CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  SliverAppBar(
                    stretch: true,
                    onStretchTrigger: () async {},
                    stretchTriggerOffset: 450.0,
                    expandedHeight: 350.0,
                    flexibleSpace: FlexibleSpaceBar(
                      titlePadding: EdgeInsets.symmetric(
                        horizontal: 24.0,
                        vertical: 16,
                      ),
                      title: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          animeProvider.isLoading
                              ? GlobalShimmer(
                                  height: 10,
                                  width: 100,
                                  borderRadius: BorderRadius.circular(24),
                                )
                              : Text(
                                  animeProvider
                                          .animeData
                                          .data[1]
                                          .titleEnglish ??
                                      "",
                                  textAlign: TextAlign.center,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(
                                    context,
                                  ).textTheme.headlineSmall,
                                ),
                          SizedBox(height: 2),
                          animeProvider.isLoading
                              ? GlobalShimmer(
                                  height: 10,
                                  width: 200,
                                  borderRadius: BorderRadius.circular(24),
                                )
                              : Text(
                                  animeProvider.animeData.data[1].synopsis ??
                                      "",
                                  textAlign: TextAlign.center,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.bodySmall,
                                ),
                          SizedBox(height: 10),
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              animeProvider.isLoading
                                  ? GlobalShimmer(
                                      height: 34,
                                      width: 80,
                                      borderRadius: BorderRadius.circular(24),
                                    )
                                  : SizedBox(
                                      height: 34,
                                      child: ElevatedButton.icon(
                                        onPressed: () {},
                                        icon: Icon(Icons.play_arrow),
                                        label: Text(
                                          "Play",
                                          style: Theme.of(
                                            context,
                                          ).textTheme.labelSmall,
                                        ),
                                      ),
                                    ),
                              animeProvider.isLoading
                                  ? GlobalShimmer(
                                      height: 34,
                                      width: 80,
                                      borderRadius: BorderRadius.circular(24),
                                    )
                                  : SizedBox(
                                      height: 34,
                                      child: OutlinedButton.icon(
                                        onPressed: () {},
                                        icon: Icon(Icons.add),
                                        label: Text(
                                          "My List",
                                          style: Theme.of(
                                            context,
                                          ).textTheme.labelSmall,
                                        ),
                                      ),
                                    ),
                            ],
                          ),
                        ],
                      ),
                      background: animeProvider.isLoading
                          ? Container(color: Colors.black)
                          : Stack(
                              fit: StackFit.expand,
                              children: [
                                Image.network(
                                  animeProvider
                                          .animeData
                                          .data[0]
                                          .images["webp"]
                                          ?.imageUrl ??
                                      "",
                                  fit: BoxFit.cover,
                                ),
                                Container(
                                  decoration: const BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        Colors.transparent,
                                        Colors.transparent,
                                        Colors.black54,
                                        Colors.black87,
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                    ),
                    actions: [
                      IconButton(onPressed: () {}, icon: Icon(Icons.settings)),
                    ],
                  ),
                  SliverList(
                    delegate: SliverChildListDelegate([
                      animeProvider.isLoading
                          ? GlobalShimmer(
                              height: 20,
                              width: 50,
                              borderRadius: BorderRadius.circular(24),
                            )
                          : SectionListTitle(title: "Trending Anime"),
                      SizedBox(height: 10),
                      SizedBox(
                        height: 250,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: animeProvider.isLoading
                              ? 5
                              : animeProvider.animeData.data.length,
                          padding: const EdgeInsets.only(left: 16),
                          separatorBuilder: (context, index) =>
                              SizedBox(width: 10),
                          itemBuilder: (context, index) {
                            return animeProvider.isLoading
                                ? GlobalShimmer(
                                    height: 150,
                                    width: 135,
                                    borderRadius: BorderRadius.circular(24),
                                  )
                                : AnimeThumbnailWidget(
                                    data: animeProvider.animeData.data[index],
                                    isLoading: animeProvider.isLoading,
                                  );
                          },
                        ),
                      ),
                      SizedBox(height: 10),
                      animeProvider.isLoading
                          ? GlobalShimmer(
                              height: 20,
                              width: 50,
                              borderRadius: BorderRadius.circular(24),
                            )
                          : SectionListTitle(title: "Upcomming Anime"),
                      SizedBox(height: 10),
                      SizedBox(
                        height: 250,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: animeProvider.isLoading
                              ? 5
                              : animeProvider.animeData.data.length,
                          padding: const EdgeInsets.only(left: 16),
                          separatorBuilder: (context, index) =>
                              SizedBox(width: 10),
                          itemBuilder: (context, index) {
                            return animeProvider.isLoading
                                ? GlobalShimmer(
                                    height: 150,
                                    width: 135,
                                    borderRadius: BorderRadius.circular(24),
                                  )
                                : AnimeThumbnailWidget(
                                    data: animeProvider.animeData.data[index],
                                    isLoading: animeProvider.isLoading,
                                  );
                          },
                        ),
                      ),
                    ]),
                  ),
                ],
              );
      },
    );
  }
}
