import 'package:anime_hub/constants/shimmer_container.dart';
import 'package:anime_hub/providers/anime_provider.dart';
import 'package:anime_hub/screens/detail_page.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class NewReleasesPage extends StatefulWidget {
  const NewReleasesPage({super.key});

  @override
  State<NewReleasesPage> createState() => _NewReleasesPageState();
}

class _NewReleasesPageState extends State<NewReleasesPage> {
  @override
  Widget build(BuildContext context) {
    return Consumer<AnimeProvider>(
      builder: (context, animePrvider, child) {
        return Scaffold(
          appBar: AppBar(title: Text("New Releases")),
          body: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            child: ListView.separated(
              itemCount: animePrvider.animeData.data.length,
              separatorBuilder: (context, index) => SizedBox(height: 10),
              itemBuilder: (context, index) {
                return animePrvider.isLoading
                    ? GlobalShimmer(height: 170)
                    : GestureDetector(
                        onTap: () {
                          if (!animePrvider.isLoading) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (builder) => DetailPage(
                                  data: animePrvider.animeData.data[index],
                                ),
                              ),
                            );
                          }
                        },
                        child: SizedBox(
                          height: 190,
                          width: MediaQuery.sizeOf(context).width,
                          child: Row(
                            children: [
                              Container(
                                width: 140,
                                height: 190,
                                decoration: BoxDecoration(
                                  color: Colors.grey,
                                  image: DecorationImage(
                                    image: NetworkImage(
                                      animePrvider
                                              .animeData
                                              .data[index]
                                              .images["webp"]
                                              ?.imageUrl ??
                                          "",
                                    ),
                                    fit: BoxFit.cover,
                                  ),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              SizedBox(width: 10),
                              SizedBox(
                                width: MediaQuery.sizeOf(context).width - 190,
                                height: 190,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      animePrvider
                                              .animeData
                                              .data[index]
                                              .titleEnglish ??
                                          "",
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: Theme.of(
                                        context,
                                      ).textTheme.headlineSmall,
                                    ),
                                    SizedBox(height: 8),
                                    Text(
                                      "Release Date:",
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyMedium
                                          ?.copyWith(color: Colors.white),
                                    ),
                                    SizedBox(height: 8),
                                    Text(
                                      "Description: ${animePrvider.animeData.data[index].synopsis}",
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 6,
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyMedium
                                          ?.copyWith(color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
              },
            ),
          ),
        );
      },
    );
  }
}
