import 'package:anime_hub/constants/app_colors.dart';
import 'package:anime_hub/providers/anime_provider.dart';
import 'package:anime_hub/screens/home_page.dart';
import 'package:anime_hub/screens/new_releases_page.dart';
import 'package:anime_hub/screens/search_page.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _selectedIndex = 0;
  static const List<Widget> _widgetOptions = <Widget>[
    HomePage(),
    SearchPage(),
    NewReleasesPage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<AnimeProvider>(
        context,
        listen: false,
      ).getAnimeData(context: context);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: _selectedIndex == 0 ? Drawer() : null,
      body: Center(child: _widgetOptions.elementAt(_selectedIndex)),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Search'),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_month),
            label: 'New Releases',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: AppColors.appRedColor,
        onTap: _onItemTapped,
      ),
    );
  }
}
