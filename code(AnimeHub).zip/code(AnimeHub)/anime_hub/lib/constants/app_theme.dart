import 'package:anime_hub/constants/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      primarySwatch: MaterialColor(0xFF4A154B, {
        50: AppColors.appRedColor.withOpacity(0.1),
        100: AppColors.appRedColor.withOpacity(0.2),
        200: AppColors.appRedColor.withOpacity(0.3),
        300: AppColors.appRedColor.withOpacity(0.4),
        400: AppColors.appRedColor.withOpacity(0.5),
        500: AppColors.appRedColor,
        600: AppColors.appRedColor.withOpacity(0.7),
        700: AppColors.appRedColor.withOpacity(0.8),
        800: AppColors.appRedColor.withOpacity(0.9),
        900: AppColors.appRedColor,
      }),
      scaffoldBackgroundColor: AppColors.backgroundColor,
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.appRedColor,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: GoogleFonts.lato(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: Colors.white,
        ),
      ),
      textTheme: GoogleFonts.latoTextTheme().copyWith(
        displayLarge: GoogleFonts.lato(
          fontSize: 32,
          fontWeight: FontWeight.bold,
          color: AppColors.primaryText,
        ),
        headlineLarge: GoogleFonts.lato(
          fontSize: 24,
          fontWeight: FontWeight.w600,
          color: AppColors.primaryText,
        ),
        bodyLarge: GoogleFonts.lato(fontSize: 16, color: AppColors.primaryText),
        bodyMedium: GoogleFonts.lato(
          fontSize: 14,
          color: AppColors.secondaryText,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.appRedColor,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.surfaceColor,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.borderLight),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.borderLight),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.appRedColor, width: 2),
        ),
      ),
      cardTheme: const CardThemeData(
        color: AppColors.cardColor,
        elevation: 2,
        margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
    );
  }

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      primarySwatch: MaterialColor(0xFF4A154B, {
        50: AppColors.appRedColor.withOpacity(0.1),
        100: AppColors.appRedColor.withOpacity(0.2),
        200: AppColors.appRedColor.withOpacity(0.3),
        300: AppColors.appRedColor.withOpacity(0.4),
        400: AppColors.appRedColor.withOpacity(0.5),
        500: AppColors.appRedColor,
        600: AppColors.appRedColor.withOpacity(0.7),
        700: AppColors.appRedColor.withOpacity(0.8),
        800: AppColors.appRedColor.withOpacity(0.9),
        900: AppColors.appRedColor,
      }),
      scaffoldBackgroundColor: AppColors.darkBackground,
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.darkBackground,
        foregroundColor: AppColors.darkPrimaryText,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: GoogleFonts.lato(
          fontSize: 24,
          fontWeight: FontWeight.w600,
          color: AppColors.darkPrimaryText,
        ),
      ),
      textTheme: GoogleFonts.latoTextTheme().copyWith(
        displayLarge: GoogleFonts.lato(
          fontSize: 32,
          fontWeight: FontWeight.bold,
          color: AppColors.darkPrimaryText,
        ),
        displaySmall: GoogleFonts.lato(
          fontSize: 28,
          fontWeight: FontWeight.bold,
          color: AppColors.darkPrimaryText,
        ),
        headlineLarge: GoogleFonts.lato(
          fontSize: 24,
          fontWeight: FontWeight.w600,
          color: AppColors.darkPrimaryText,
        ),
        headlineMedium: GoogleFonts.lato(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: AppColors.darkPrimaryText,
        ),
        headlineSmall: GoogleFonts.lato(
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: AppColors.darkPrimaryText,
        ),
        bodyLarge: GoogleFonts.lato(
          fontSize: 16,
          color: AppColors.darkPrimaryText,
        ),
        bodyMedium: GoogleFonts.lato(
          fontSize: 14,
          color: AppColors.darkSecondaryText,
        ),
        bodySmall: GoogleFonts.lato(
          fontSize: 12,
          color: AppColors.darkSecondaryText,
        ),
        labelSmall: GoogleFonts.lato(
          fontSize: 12,
          color: AppColors.darkPrimaryText,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.appRedColor,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(26),
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          side: BorderSide(
            color: Colors.white, // Your desired border color
            width: 1.0,
          ),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(26),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.darkSurface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.borderDark),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.borderDark),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.appRedColor, width: 2),
        ),
      ),
      cardTheme: const CardThemeData(
        color: AppColors.darkCard,
        elevation: 2,
        margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
    );
  }
}
