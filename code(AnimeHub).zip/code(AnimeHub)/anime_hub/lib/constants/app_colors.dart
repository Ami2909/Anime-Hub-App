import 'package:flutter/material.dart';

class AppColors {
  // Primary Slack Colors
  static const Color appRedColor = Color.fromARGB(255, 201, 46, 46);

  // Background Colors
  static const Color backgroundColor = Color(0xFFF8F8F8);
  static const Color surfaceColor = Color(0xFFFFFFFF);
  static const Color cardColor = Color(0xFFFFFFFF);

  // Dark Theme Colors
  static const Color darkBackground = Color.fromARGB(255, 1, 1, 1);
  static const Color darkSurface = Color(0xFF232937);
  static const Color darkCard = Color(0xFF2C3142);

  // Text Colors
  static const Color primaryText = Color(0xFF1D1C1D);
  static const Color secondaryText = Color(0xFF616061);
  static const Color darkPrimaryText = Color(0xFFFFFFFF);
  static const Color darkSecondaryText = Color(0xFFABABAB);

  // Border Colors
  static const Color borderLight = Color(0xFFE1E1E1);
  static const Color borderDark = Color(0xFF444444);
}